import React from 'react';
import image1 from './assets/image1.jpg';
import image2 from './assets/image2.jpg';
import { Navbar, Nav, Container, Row, Col, Card, Carousel, FormControl } from 'react-bootstrap';
import './App.css';

const App = () => {
  return (
    <div>
      {/* Header Section */}
      <Navbar bg="light" expand="lg" className="p-3">
        <Container>
          <Navbar.Brand href="#">
            <img src="https://via.placeholder.com/40" alt="Logo" className="rounded-circle" />
            <span className="ml-2">First Name Second Name</span>
          </Navbar.Brand>
          <FormControl type="text" placeholder="Search" className="mr-sm-2 search-bar" />
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="ml-auto">
              <Nav.Link href="#">About Me</Nav.Link>
              <Nav.Link href="#">Categories</Nav.Link>
              <button className="btn btn-primary">Login</button>
            </Nav>
          </Navbar.Collapse>
        </Container>
      </Navbar>

      {/* Carousel Section */}
      <Carousel className="mt-4">
        <Carousel.Item>
          <img
            className="d-block w-100"
            src={image2}
            alt="First slide"
          />
          <Carousel.Caption>
            <h3>Standard Chartered EaseMyTrip Credit Card</h3>
            <p>Enjoy flat 20% & 10% discount on hotel & flight bookings.</p>
            <button className="btn btn-warning">Apply Now</button>
          </Carousel.Caption>
        </Carousel.Item>
        <Carousel.Item>
          <img
            className="d-block w-100"
            src= {image1}
            alt="Second slide"
          />
          <Carousel.Caption>
            <h3>Exclusive Gadgets Sale</h3>
            <p>Up to 50% off on the latest gadgets.</p>
            <button className="btn btn-success">Shop Now</button>
          </Carousel.Caption>
        </Carousel.Item>
      </Carousel>

      {/* Product Recommendation Section */}
      <Container className="mt-5">
        <h2>Products Recommendation</h2>
        <Row>
          {/* Category 1 */}
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Apple HomePod mini-Orange</Card.Title>
                <Card.Text>₹15,000.00</Card.Text>
                <button className="btn btn-primary">Buy Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Meters Music Connect White OV-1-B</Card.Title>
                <Card.Text>₹25,000.00</Card.Text>
                <button className="btn btn-primary">Call Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Asus Zenbook Pro 13"</Card.Title>
                <Card.Text>₹32,000.00</Card.Text>
                <button className="btn btn-primary">Apply</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Apple HomePod mini-Orange</Card.Title>
                <Card.Text>₹15,000.00</Card.Text>
                <button className="btn btn-primary">Buy Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Meters Music Connect White OV-1-B</Card.Title>
                <Card.Text>₹25,000.00</Card.Text>
                <button className="btn btn-primary">Call Now</button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
        {/* Category 1 */}
        <h4 className="mt-4">Category 1</h4>
        <Row>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Apple HomePod mini-Orange</Card.Title>
                <Card.Text>₹15,000.00</Card.Text>
                <button className="btn btn-primary">Buy Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Meters Music Connect White OV-1-B</Card.Title>
                <Card.Text>₹25,000.00</Card.Text>
                <button className="btn btn-primary">Call Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Asus Zenbook Pro 13"</Card.Title>
                <Card.Text>₹32,000.00</Card.Text>
                <button className="btn btn-primary">Apply</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Apple HomePod mini-Orange</Card.Title>
                <Card.Text>₹15,000.00</Card.Text>
                <button className="btn btn-primary">Buy Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Meters Music Connect White OV-1-B</Card.Title>
                <Card.Text>₹25,000.00</Card.Text>
                <button className="btn btn-primary">Call Now</button>
              </Card.Body>
            </Card>
          </Col>
        </Row>

        {/* Category 2 */}
        <h4 className="mt-4">More Products</h4>
        <Row>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Kotak811 Credit Card</Card.Title>
                <Card.Text>Access 1000 VIP lounges</Card.Text>
                <button className="btn btn-primary">Click Now</button>
              </Card.Body>
            </Card>
          </Col>
          <Col md={4}>
            <Card className="mb-4">
              <Card.Img variant="top" src="https://via.placeholder.com/150" />
              <Card.Body>
                <Card.Title>Kotak811 Credit Card</Card.Title>
                <Card.Text>Access 1000 VIP lounges</Card.Text>
                <button className="btn btn-primary">Apply</button>
              </Card.Body>
            </Card>
          </Col>
        </Row>
      </Container>

      {/* Brands Section */}
      <Container className="mt-5">
        <h2>Brands</h2>
        <Row>
          {["Ford", "Chevrolet", "Audi", "Hyundai", "Nissan", "BMW", "Mercedes", "Toyota", "Suzuki", "Mitsubishi", "Honda", "Volvo"].map(brand => (
            <Col xs={6} sm={3} md={2} className="mb-4 text-center" key={brand}>
              <img src={`https://via.placeholder.com/100?text=${brand}`} alt={brand} className="img-fluid" />
              <p>{brand}</p>
            </Col>
          ))}
        </Row>
      </Container>

      {/* Categories Section */}
      <Container className="mt-5">
        <h2>Categories</h2>
        <Row>
          {Array(12).fill("Category").map((category, index) => (
            <Col xs={6} sm={4} md={3} className="mb-3 text-center" key={index}>
              <button className="btn btn-outline-secondary w-100">{category}</button>
            </Col>
          ))}
        </Row>
      </Container>

      {/* Footer Section */}
      <footer className="bg-dark text-light text-center p-4">
        <Container>
          <h5>Watch Me Here</h5>
          <button className="btn btn-danger mx-2">YouTube</button>
          <button className="btn btn-warning mx-2">Instagram</button>
          <button className="btn btn-warning mx-2">Instagram</button>
        </Container>
        <Container className="mt-3">
          <p>© 2024 Chord AI | Privacy Policy | Terms & Conditions</p>
        </Container>
      </footer>
    </div>
  );
};

export default App;